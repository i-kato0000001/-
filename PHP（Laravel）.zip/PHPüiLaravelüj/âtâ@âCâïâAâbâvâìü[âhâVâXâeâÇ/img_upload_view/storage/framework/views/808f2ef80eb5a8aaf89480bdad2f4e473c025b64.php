<form action="<?php echo e(route('item.store')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <input type="file" name="img_path">
    <input type="submit" value="アップロード">
</form>
<br>
<a href="<?php echo e(route('item.index')); ?>">一覧画面へ</a>
<?php /**PATH C:\xampp\htdocs\laravel\img_upload_view\resources\views/item/create.blade.php ENDPATH**/ ?>