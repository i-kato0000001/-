<h1>一覧画面</h1>
<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <img src="<?php echo e(Storage::url($item->img_path)); ?>" width="25%">
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<br>
<a href="<?php echo e(route('item.create')); ?>">UpLoad画面へ</a>
<?php /**PATH C:\xampp\htdocs\laravel\img_upload_view\resources\views/item/index.blade.php ENDPATH**/ ?>