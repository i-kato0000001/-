package com.example.mypass;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.speech.RecognizerIntent;
import android.text.method.ScrollingMovementMethod;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private TextView textView;
    private TextView readFileText;
    private int lang;
    private String readText = null;
    private String test;

    ActivityResultLauncher resultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK) {
                    Intent resultData = result.getData();
                    if (resultData != null) {
                        // 認識結果を ArrayList で取得
                        ArrayList candidates =
                                resultData.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);

                        if (candidates.size() > 0) {
                            // 認識結果候補で一番有力なものを表示
                            textView.setText((CharSequence) candidates.get(0));
                            test = String.valueOf(textView.getText());
                            if (test != null) {
                                writeToFile(test);
                                try {
                                    readText = readFromFile();
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                                if (readText != null) {
                                    readFileText.setText(readText);

                                }
                            }

                        }
                    }
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 言語選択 0:日本語、1:英語、2:オフライン、その他:General
        lang = 0;

        // 認識結果を表示させる
        textView = findViewById(R.id.text_view);
        textView.setMovementMethod(new ScrollingMovementMethod());

        readFileText = findViewById(R.id.text_view_read_file_text);
        readFileText.setMovementMethod(new ScrollingMovementMethod());

        Button buttonStart = findViewById(R.id.button_start);
        Button buttonAllClear = findViewById(R.id.button_clear);
        buttonStart.setOnClickListener(v -> {
            // 音声認識を開始
            speech();
        });
        buttonAllClear.setOnClickListener(v -> {
            deleteToFile();
        });
    }

    private void deleteToFile() {
        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        alert.setTitle("削除処理");
        alert.setMessage("記録内容をすべて削除してもよろしいですか？");
        alert.setPositiveButton("削除します", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                //Yesボタンが押された時の処理
                deleteFile("minutes.txt");
                readFileText.setText("");
            }
        }).setNegativeButton("削除しません", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                //Noボタンが押された時の処理
                return;
            }
        });
        alert.show();

    }

    private void speech() {
        // 音声認識の　Intent インスタンス
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);

        if (lang == 0) {
            // 日本語
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.JAPAN.toString());
        } else if (lang == 1) {
            // 英語
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.ENGLISH.toString());
        } else if (lang == 2) {
            // Off line mode
            intent.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true);
        } else {
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        }

        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 100);
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "音声を入力");

        try {
            // インテント発行
            resultLauncher.launch(intent);
        } catch (ActivityNotFoundException e) {
            e.printStackTrace();
            textView.setText(R.string.error);
        }
    }


    private void writeToFile(String message) {
        try {
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(openFileOutput("minutes.txt", Context.MODE_PRIVATE | MODE_APPEND));
            outputStreamWriter.write(message + "\r\n");
//            outputStreamWriter.flush();
            outputStreamWriter.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private String readFromFile() throws IOException {
        String result = "";
        InputStream inputStream = openFileInput("minutes.txt");

        if (inputStream != null) {
            InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

            String tempString = "";
            StringBuilder stringBuilder = new StringBuilder();

            while ((tempString = bufferedReader.readLine()) != null) {
                stringBuilder.append(tempString + "\r\n");
            }
            inputStream.close();
            result = stringBuilder.toString();
        }
        return result;
    }

}