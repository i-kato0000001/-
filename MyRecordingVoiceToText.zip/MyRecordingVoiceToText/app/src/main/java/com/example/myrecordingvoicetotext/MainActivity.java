package com.example.myrecordingvoicetotext;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class MainActivity extends AppCompatActivity
        implements View.OnClickListener, RecognitionListener {

    private static final int PERMISSION_RECORD_AUDIO = 1;

    private Button mButton;
    private Button mButtonAllClear;
    private TextView mText;
    private TextView mReadFileText;



    private SpeechRecognizer mRecorder;
    private AlertDialog.Builder mAlert;
    private String readText = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mButton = (Button)findViewById(R.id.speech_button);

        mReadFileText = (TextView)findViewById(R.id.output_text);

        mText = (TextView)findViewById(R.id.output_text2);
        mButton.setOnClickListener(this);
        mButtonAllClear = (Button)findViewById(R.id.button_clear);
        mRecorder = null;

        mAlert = new AlertDialog.Builder(this);
        mAlert.setTitle(getString(R.string.error));
        mAlert.setPositiveButton(getString(R.string.ok), null);

        checkRecordable();

        mButtonAllClear.setOnClickListener(v -> {
            deleteToFile();
        });

    }

    public Boolean checkRecordable(){
        if(!SpeechRecognizer.isRecognitionAvailable(getApplicationContext())) {
            //mAlert.setMessage(getString(R.string.speech_not_available));
            //mAlert.show();
            mText.setText(getString(R.string.speech_not_available));
            return false;
        }
        if (Build.VERSION.SDK_INT >= 23) {
            if(ActivityCompat.checkSelfPermission(this,
                    Manifest.permission.RECORD_AUDIO)
                    != PackageManager.PERMISSION_GRANTED)
            {
                mText.setText(getString(R.string.speech_not_granted));
                ActivityCompat.requestPermissions(this,
                        new String[]{
                                Manifest.permission.RECORD_AUDIO
                        },
                        PERMISSION_RECORD_AUDIO);
                return false;
            }
        }
        return true;
    }


    @Override
    public void onRequestPermissionsResult(
            int requestCode, String[] permission, int[] grantResults
    ) {
        super.onRequestPermissionsResult(requestCode, permission, grantResults);
        Log.d("MainActivity", "onRequestPermissionsResult");

        if (grantResults.length <= 0) {
            return;
        }
        switch (requestCode) {
            case PERMISSION_RECORD_AUDIO:
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    mText.setText("");
                } else {

                }
                break;
        }
    }

    public void stopRecording(){
        if(mRecorder != null && checkRecordable()) {
            mRecorder.stopListening();
            mRecorder.cancel();
            mRecorder.destroy();
            mRecorder = null;

        }
    }

    public void startRecording(){
        if(mRecorder == null && checkRecordable()) {
//            mText.setText(getString(R.string.prepare_speech));
            mRecorder = SpeechRecognizer.createSpeechRecognizer(this);
            mRecorder.setRecognitionListener(this);
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE,
                    getPackageName());
            //以下指定で途中の認識を拾う
            intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
            mRecorder.startListening(intent);
            mButton.setText(getString(R.string.stop_speech));
        }
    }

    @Override
    public void onClick(View v) {
        if(v.getId() != R.id.speech_button){
            stopRecording();
            return;
        }
        if(mRecorder != null){
            stopRecording();
            mButton.setText(getString(R.string.start_speech));
        }
        else{
            mText.setText("");
            startRecording();
        }
    }

    @Override
    public void onReadyForSpeech(Bundle params) {
        Log.d("MainActivity","onReadyForSpeech");
 //       mText.setText(getString(R.string.ready_speech));
        startRecording();
    }

    @Override
    public void onBeginningOfSpeech() {
        Log.d("MainActivity","onBeginningOfSpeech");

    }

    @Override
    public void onBufferReceived(byte[] buffer) {
        Log.d("MainActivity","onBufferReceived");
    }

    @Override
    public void onRmsChanged(float rmsdB) {
        Log.d("MainActivity","onRmsChanged");

    }

    @Override
    public void onEndOfSpeech() {
        Log.d("MainActivity","onEndOfSpeech");
 //       stopRecording();
 //           startRecording();
    }

    @Override
    public void onError(int error) {
        Log.d("MainActivity","onError.error="+error);
        //mAlert.setMessage(getString(R.string.speech_error) + "\nエラーコード：" + error);
        //mAlert.show();
 //       mText.setText(getString(R.string.speech_error) + "\nエラーコード：" + error);
        stopRecording();
        if(error == 7){
            startRecording();
        }
    }

    @Override
    public void onEvent(int eventType, Bundle params) {
        Log.d("MainActivity","onEvent.eventType="+eventType);
    }

    @Override
    public void onPartialResults(Bundle partialResults) {
        Log.d("MainActivity","onPartialResults");
        String str = partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).get(0);
        if(str.length() > 0) {
            mText.setText(str);

                writeToFile(str);
                try {
                    readText = readFromFile();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                if (readText != null) {
                    mReadFileText.setText(readText);

                }


        }
    }

    @Override
    public void onResults(Bundle results) {
        Log.d("MainActivity","onResults");

        stopRecording();
        startRecording();
    }



    private void deleteToFile() {
        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        alert.setTitle("削除処理");
        alert.setMessage("記録内容をすべて削除してもよろしいですか？");
        alert.setPositiveButton("削除します", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                //Yesボタンが押された時の処理
                deleteFile("minutes.txt");
                mText.setText("");
                mReadFileText.setText("");
            }
        }).setNegativeButton("削除しません", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                //Noボタンが押された時の処理
                return;
            }
        });
        alert.show();

    }

    private void writeToFile(String message) {
        try {
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(openFileOutput("minutes.txt", Context.MODE_PRIVATE | MODE_APPEND));
            outputStreamWriter.write(message + "\r\n");
//            outputStreamWriter.flush();
            outputStreamWriter.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    private String readFromFile() throws IOException {
        String result = "";
        InputStream inputStream = openFileInput("minutes.txt");

        if (inputStream != null) {
            InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

            String tempString = "";
            StringBuilder stringBuilder = new StringBuilder();

            while ((tempString = bufferedReader.readLine()) != null) {
                stringBuilder.append(tempString + "\r\n");
            }
            inputStream.close();
            result = stringBuilder.toString();
        }
        return result;
    }




}